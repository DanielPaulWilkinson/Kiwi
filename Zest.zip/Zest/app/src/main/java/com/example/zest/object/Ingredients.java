package com.example.zest.object;

public class Ingredients {

    Ingredients(){}

    public int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getAmount() {
        return amount;
    }

    public void setAmount(int amount) {
        this.amount = amount;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getFreezeable() {
        return freezeable;
    }

    public void setFreezeable(String freezeable) {
        this.freezeable = freezeable;
    }

    public Ingredients(int id, int amount, String name, String description, String freezeable, String measurement) {
        this.id = id;
        this.amount = amount;
        this.name = name;
        this.description = description;
        this.freezeable = freezeable;
        this.measurement = measurement;
    }

    public int amount;
    public String name;
    public String description;
    public String freezeable;

    public String getMeasurement() {
        return measurement;
    }

    public void setMeasurement(String measurement) {
        this.measurement = measurement;
    }

    public String measurement;
}
