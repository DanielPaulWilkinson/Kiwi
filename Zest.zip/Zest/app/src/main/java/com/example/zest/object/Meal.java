package com.example.zest.object;

import android.text.format.Time;

import java.util.List;

public class Meal {
    public int id, stars, favourate, difficulty, serves, vegan, Vegetarian, gluten;
    public String name, description, coverPhoto, mainPhoto, source;
    public List<String> method, nutrition, tags;

    public Meal(){}

    public Meal(int id, int stars, int favourate, int difficulty, int serves, int vegan, int vegetarian, int gluten, String name, String description, String coverPhoto, String mainPhoto, String source, List<String> method, List<String> nutrition, List<String> tags, Ingredients ingredients, Time preptime) {
        this.id = id;
        this.stars = stars;
        this.favourate = favourate;
        this.difficulty = difficulty;
        this.serves = serves;
        this.vegan = vegan;
        Vegetarian = vegetarian;
        this.gluten = gluten;
        this.name = name;
        this.description = description;
        this.coverPhoto = coverPhoto;
        this.mainPhoto = mainPhoto;
        this.source = source;
        this.method = method;
        this.nutrition = nutrition;
        this.tags = tags;
        this.ingredients = ingredients;
        this.preptime = preptime;
    }

    public Ingredients ingredients;
    public Time preptime;

    public int getId() {
        return id;
    }

    public int getStars() {
        return stars;
    }

    public int getFavourate() {
        return favourate;
    }

    public int getDifficulty() {
        return difficulty;
    }

    public int getServes() {
        return serves;
    }

    public int getVegan() {
        return vegan;
    }

    public int getVegetarian() {
        return Vegetarian;
    }

    public int getGluten() {
        return gluten;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    public String getCoverPhoto() {
        return coverPhoto;
    }

    public String getMainPhoto() {
        return mainPhoto;
    }

    public String getSource() {
        return source;
    }

    public List<String> getMethod() {
        return method;
    }

    public List<String> getNutrition() {
        return nutrition;
    }

    public List<String> getTags() {
        return tags;
    }

    public Ingredients getIngredients() {
        return ingredients;
    }

    public Time getPreptime() {
        return preptime;
    }
}

